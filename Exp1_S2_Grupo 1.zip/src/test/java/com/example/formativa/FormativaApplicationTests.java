package com.example.formativa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormativaApplicationTests {

	@Test
	void contextLoads() {
	}

}
